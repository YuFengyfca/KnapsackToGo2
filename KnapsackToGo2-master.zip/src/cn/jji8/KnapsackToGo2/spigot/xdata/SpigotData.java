package cn.jji8.KnapsackToGo2.spigot.xdata;

import cn.jji8.KnapsackToGo2.xdata.Data;
/**
 * 子服务器用于与蹦极通信的类
 * */
public class SpigotData extends Data {
    //还没开始写，哈哈

}
