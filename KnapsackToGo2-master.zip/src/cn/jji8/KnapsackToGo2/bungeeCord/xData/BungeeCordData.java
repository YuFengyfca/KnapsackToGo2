package cn.jji8.KnapsackToGo2.bungeeCord.xData;

import cn.jji8.KnapsackToGo2.xdata.Data;
/**
 * 用于与子服务器通信的类
 * */
public class BungeeCordData extends Data {
    //还没开始写，哈哈
}
