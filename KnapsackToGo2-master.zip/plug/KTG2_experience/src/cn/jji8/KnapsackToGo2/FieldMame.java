package cn.jji8.KnapsackToGo2;
/**
 * 一个常量列表
 * */
public class FieldMame {
    //常量，就算是玩家利用了这些代码也不会出现问题的
    public static final String
            //玩家数据名
            Home_Data_Name = "KTG2_experience_home",
            //玩家默认家的名字
            Player_Default_Home_Name = "Default",
            //向子服务器发送的回家的命令
            Sub_Go_Home_command = "//32adg657d324dh3//",
            //向子服务器发送的设置家的命令
            Sub_Set_Home_command = "//adkslyakbsdgli//",
            //向子服务器发送的回城命令
            Sub_Spawn_Command = "//afdkjglabsdg//",
            //向子服务器发送设置主城的命令
            Sub_SetSpawn_Command = "//asd4asdgasd4g3//";


    //变量，不可以让玩家轻易获得的，泄露可能发生问题的
    public static String
            //向子服务器发送TPA的命令
            Sub_Tpa_Command = "//ioagkdfhihakls//";
}
